const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://ers:ers6545@cluster0.dilgoqc.mongodb.net/documentmanager?retryWrites=true&w=majority&appName=Cluster0', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('✅ Подключено к MongoDB'))
.catch(err => console.error('❌ Ошибка подключения к MongoDB:', err));


const app = express();
const PORT = 5000;
const SECRET_KEY = 'supersecretkey';

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Создать папку uploads, если не существует
if (!fs.existsSync('./uploads')) {
  fs.mkdirSync('./uploads');
}

// Настройка загрузки файлов
const storage = multer.diskStorage({
  destination: './uploads/',
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const name = path.basename(file.originalname, ext)
      .replace(/[^a-zA-Z0-9-_]/g, '_');
    const unique = Date.now();
    cb(null, `${unique}_${name}${ext}`);
  }
});
const upload = multer({ storage });

// Имитация базы данных
const users = [];
const documents = []; // { id, title, content, file, tag, createdAt, username }

// Регистрация
app.post('/api/register', (req, res) => {
  const { username, password } = req.body;
  if (users.find(u => u.username === username)) {
    return res.status(400).json({ message: 'Пользователь уже существует' });
  }
  const hashedPassword = bcrypt.hashSync(password, 8);
  users.push({ username, password: hashedPassword });
  res.json({ message: 'Регистрация прошла успешно' });
});

// Авторизация
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const user = users.find(u => u.username === username);
  if (!user || !bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ message: 'Неверные данные' });
  }
  const token = jwt.sign({ username }, SECRET_KEY, { expiresIn: '1h' });
  res.json({ token });
});

// Проверка токена
function auth(req, res, next) {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'Нет токена' });
  jwt.verify(token, SECRET_KEY, (err, user) => {
    if (err) return res.status(403).json({ message: 'Недействительный токен' });
    req.user = user;
    next();
  });
}

// Получить все документы
app.get('/api/documents', auth, (req, res) => {
  const docs = documents.filter(doc => doc.username === req.user.username);
  res.json(docs);
});

// Создать новый документ
app.post('/api/documents', auth, upload.single('file'), (req, res) => {
  const { title, content, tag } = req.body;
  const file = req.file ? req.file.filename : null;

  const newDoc = {
    id: Date.now().toString(),
    title,
    content,
    tag: tag || 'Без категории',
    file,
    createdAt: new Date().toISOString(),
    username: req.user.username
  };

  documents.push(newDoc);
  res.json({ message: 'Документ создан', doc: newDoc });
});

// Обновить документ
app.put('/api/documents/:id', auth, upload.single('file'), (req, res) => {
  const { title, content, tag } = req.body;
  const doc = documents.find(d => d.id === req.params.id && d.username === req.user.username);
  if (!doc) return res.status(404).json({ message: 'Документ не найден' });

  doc.title = title;
  doc.content = content;
  doc.tag = tag || 'Без категории';
  if (req.file) {
    if (doc.file) fs.unlinkSync('./uploads/' + doc.file);
    doc.file = req.file.filename;
  }

  res.json({ message: 'Документ обновлён', doc });
});

// Удалить документ
app.delete('/api/documents/:id', auth, (req, res) => {
  const index = documents.findIndex(d => d.id === req.params.id && d.username === req.user.username);
  if (index === -1) return res.status(404).json({ message: 'Документ не найден' });

  const doc = documents[index];
  if (doc.file) fs.unlinkSync('./uploads/' + doc.file);
  documents.splice(index, 1);

  res.json({ message: 'Документ удалён' });
});

// Запуск сервера
app.listen(PORT, () => {
  console.log(`✅ Сервер работает: http://localhost:${PORT}`);
});
